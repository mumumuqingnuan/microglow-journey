import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {join} from 'node:path';
const root=new URL('../',import.meta.url);
const read=p=>readFile(new URL(p,root),'utf8');
let html=await read('dist/client/index.html');
const assets={};
for(const file of await readdir(new URL('public/assets/',root))){
 if(!file.endsWith('.webp'))continue;
 assets[file.replace(/\.webp$/,'')]='data:image/webp;base64,'+(await readFile(new URL('public/assets/'+file,root))).toString('base64');
}
const script=html.match(/<script[^>]+src="([^"]+)"[^>]*><\/script>/);
const css=html.match(/<link[^>]+href="([^"]+\.css)"[^>]*>/);
if(!script||!css)throw new Error('Build output did not contain expected JS and CSS files');
const safe=s=>s.replace(/<\/script/gi,'<\\/script');
const js=await read(join('dist/client',script[1]));
const style=await read(join('dist/client',css[1]));
html=html.replace(script[0],()=>`<script>window.__MICROGLOW_ASSETS=${safe(JSON.stringify(assets))};</script><script type="module">${safe(js)}</script>`).replace(css[0],()=>`<style>${style}</style>`);
await mkdir(new URL('pages/',root),{recursive:true});
await writeFile(new URL('pages/index.html',root),html);
await writeFile(new URL('pages/.nojekyll',root),'');
console.log(`Self-contained GitHub Pages build: ${Buffer.byteLength(html)} bytes`);
