import assert from 'node:assert/strict';
import test from 'node:test';
import {STORY_ROUTES} from '../src/storyContent.js';
import {createStoryState,resolveStory,chooseStory,storyText} from '../src/story.js';

// Keep the narrative engine tests independent of image assets and browser globals.
const cards=Array.from({length:36},(_,id)=>({id,scene:`第 ${id} 张卡片的启程风景。`}));

function sessionFor(routeId=STORY_ROUTES[0].id,selected=[18,0,35]){
 return {id:'test-journey',mode:'story',journeyTone:'any',selected,
  story:{version:2,routeId,decision:null}};
}

function choose(session,index){
 return {...session,story:chooseStory(session,cards,index)};
}

test('all six routes can be drawn, with exactly two routes for each requested tone',()=>{
 assert.equal(STORY_ROUTES.length,6);
 assert.equal(new Set(STORY_ROUTES.map(r=>r.id)).size,6);
 for(const tone of ['wonder','comfort','surprise']){
  const expected=STORY_ROUTES.filter(r=>r.tone===tone).map(r=>r.id).sort();
  assert.equal(expected.length,2);
  const reached=new Set();
  for(let i=0;i<128;i++){
   const state=createStoryState({id:`tone-${i}`,journeyTone:tone,selected:[i%36]});
   assert.ok(expected.includes(state.routeId),`${tone} drew an unrelated route`);
   reached.add(state.routeId);
  }
  assert.deepEqual([...reached].sort(),expected);
 }
 const reached=new Set(Array.from({length:256},(_,i)=>
  createStoryState({id:`any-${i}`,journeyTone:'any',selected:[i%36]}).routeId));
 assert.deepEqual([...reached].sort(),STORY_ROUTES.map(r=>r.id).sort());
});

test('a journey avoids the two most recent routes when the chosen pool permits it',()=>{
 const recent=STORY_ROUTES.slice(0,2).map(r=>r.id);
 for(let i=0;i<64;i++){
  const state=createStoryState({id:`fresh-${i}`,journeyTone:'any',selected:[i%36]},recent);
  assert.ok(!recent.includes(state.routeId));
 }
 for(const tone of ['wonder','comfort','surprise']){
  const [latest,older]=STORY_ROUTES.filter(r=>r.tone===tone).map(r=>r.id);
  const input={id:'keep-tone',journeyTone:tone,selected:[17]};
  assert.equal(createStoryState(input,[latest]).routeId,older);
  assert.equal(createStoryState(input,[latest,older]).routeId,older,
   'an exhausted tone must still avoid repeating its most recent route');
 }
});

test('route selection and the rendered story remain deterministic for the same session',()=>{
 const input={id:'stable-id',mode:'story',journeyTone:'surprise',selected:[6,13,31]};
 const previous=[STORY_ROUTES[0].id];
 const state=createStoryState(input,previous);
 for(let i=0;i<10;i++)assert.deepEqual(createStoryState(structuredClone(input),previous),state);
 const session={...input,story:state};
 assert.deepEqual(resolveStory(session,cards),resolveStory(structuredClone(session),cards));
 assert.equal(resolveStory(session,cards).opening[0],cards[6].scene);
 assert.deepEqual(createStoryState({...input,journeyTone:'obsolete-setting'}),
  createStoryState({...input,journeyTone:'any'}));
});

test('the second card offers different pairs of actions, with all authored actions reachable',()=>{
 for(const route of STORY_ROUTES){
  const pairs=[];
  const reachable=new Set();
  for(const second of [0,1,2]){
   const result=resolveStory(sessionFor(route.id,[18,second,35]),cards);
   assert.equal(result.choices.length,2);
   assert.equal(new Set(result.choices.map(c=>c.label)).size,2);
   pairs.push(result.choices.map(c=>c.index).join(','));
   for(const action of result.choices)reachable.add(action.index);
  }
  assert.equal(new Set(pairs).size,3,`${route.id} ignored the second card`);
  assert.deepEqual([...reachable].sort(),[0,1,2]);
 }
});

test('all eighteen authored branches produce their event, reveal, afterglow and keepsake',()=>{
 const reached=new Set();
 const endings=new Set();
 for(const route of STORY_ROUTES){
  assert.equal(route.choices.length,3);
  for(const second of [0,1,2]){
   const session=sessionFor(route.id,[18,second,35]);
   for(const available of resolveStory(session,cards).choices){
    const result=resolveStory(choose(session,available.index),cards);
    const authored=route.choices[available.index];
    assert.equal(result.decision,available.index);
    assert.equal(result.choiceLabel,authored.label);
    assert.deepEqual(result.ending,[authored.consequence,authored.reveal,authored.afterglow]);
    assert.ok(result.ending.every(p=>typeof p==='string'&&p.trim().length>15));
    assert.equal(result.keepsake.name,authored.keepsake);
    reached.add(`${route.id}:${available.index}`);
    endings.add(result.ending.join('\n'));
   }
  }
 }
 assert.equal(reached.size,18);
 assert.equal(endings.size,18,'authored branches must not collapse to duplicated outcomes');
});

test('taking the alternate action changes events and ending; returning restores the first result',()=>{
 for(const route of STORY_ROUTES){
  const session=sessionFor(route.id);
  const untouched=structuredClone(session);
  const [a,b]=resolveStory(session,cards).choices;
  const firstSession=choose(session,a.index);
  const first=resolveStory(firstSession,cards);
  const otherSession=choose(firstSession,b.index);
  const other=resolveStory(otherSession,cards);
  assert.notEqual(first.ending[0],other.ending[0]);
  assert.notEqual(first.ending[1],other.ending[1]);
  assert.notEqual(first.ending[2],other.ending[2]);
  assert.notEqual(first.keepsake.name,other.keepsake.name);
  assert.deepEqual(resolveStory(choose(otherSession,a.index),cards),first);
  assert.deepEqual(session,untouched,'choosing must not mutate a saved or current session');
 }
});

test('saved story snapshots survive JSON storage exactly, including export text',()=>{
 for(const route of STORY_ROUTES){
  const session=sessionFor(route.id);
  const completed=choose(session,resolveStory(session,cards).choices[0].index);
  const expected=resolveStory(completed,cards);
  const stored=JSON.parse(JSON.stringify(completed));
  assert.deepEqual(resolveStory(stored,cards),expected);
  assert.equal(storyText(resolveStory(stored,cards)),storyText(expected));
  // A saved narrative must keep its original wording even if card copy changes later.
  const revisedCards=cards.map(c=>({...c,scene:'更新后的卡片说明。'}));
  assert.deepEqual(resolveStory(stored,revisedCards),expected);
 }
});

test('unresolved journeys disclose no ending or keepsake and cannot accept a hidden action',()=>{
 const session=sessionFor();
 const result=resolveStory(session,cards);
 assert.equal(result.decision,null);
 assert.deepEqual(result.ending,[]);
 assert.equal(result.keepsake,null);
 assert.equal(result.choiceLabel,'');
 const hidden=STORY_ROUTES[0].choices.map((_,i)=>i).find(i=>!result.choices.some(c=>c.index===i));
 assert.strictEqual(chooseStory(session,cards,hidden),session.story);
 assert.strictEqual(chooseStory(session,cards,999),session.story);
 const text=storyText(result);
 assert.ok(!text.includes('你的选择：'));
 assert.ok(!text.includes('旅途纪念物'));
 for(const branch of STORY_ROUTES[0].choices)assert.ok(!text.includes(branch.reveal));
});

test('partially drawn or unavailable cards do not fabricate a complete story',()=>{
 for(const selected of [[],[0],[0,1],[0,1,2,3],[0,1,99]]){
  const session=sessionFor(STORY_ROUTES[0].id,selected);
  assert.equal(resolveStory(session,cards),null);
  assert.strictEqual(chooseStory(session,cards,0),session.story);
 }
 assert.equal(resolveStory(sessionFor('missing-route'),cards),null);
});

test('legacy story records and other modes stay outside the new engine',()=>{
 const legacy={id:'old',mode:'story',selected:[0,1,2],choice:1};
 assert.equal(resolveStory(legacy,cards),null);
 assert.equal(resolveStory({...legacy,story:{version:1}},cards),null);
 for(const mode of ['spark','journal'])assert.equal(resolveStory({...sessionFor(),mode},cards),null);
 assert.equal(resolveStory(null,cards),null);
 assert.equal(storyText(null),'');
});

test('each of the thirty-six third cards contributes a distinct souvenir and description',()=>{
 const descriptions=new Set();
 const gifts=new Set();
 for(let third=0;third<36;third++){
  const session=sessionFor(STORY_ROUTES[0].id,[(third+1)%36,(third+2)%36,third]);
  const choice=resolveStory(session,cards).choices[0].index;
  const result=resolveStory(choose(session,choice),cards);
  assert.ok(result.cardGift);
  assert.ok(result.keepsake.description.includes(result.cardGift));
  assert.ok(!result.keepsake.description.includes('undefined'));
  descriptions.add(result.keepsake.description);
  gifts.add(result.cardGift);
 }
 assert.equal(descriptions.size,36);
 assert.equal(gifts.size,36);
});

test('export text includes only the selected outcome, plus its full souvenir description',()=>{
 const session=sessionFor();
 const [selected,alternative]=resolveStory(session,cards).choices;
 const result=resolveStory(choose(session,selected.index),cards);
 const text=storyText(result);
 for(const paragraph of [result.title,...result.opening,...result.encounter,...result.ending,
  result.keepsake.name,result.keepsake.description])assert.ok(text.includes(paragraph));
 assert.ok(text.includes(`你的选择：${selected.label}`));
 assert.ok(!text.includes(STORY_ROUTES[0].choices[alternative.index].reveal));
});
