# Design QA — 月隐 · 微光旅途

final result: passed

## Source and comparison scope

Source visual truth: `/workspace/scratch/4ca9dede5902/upload/image-edit-target-58f351d157076d72.png`, 1536 × 1024 pixels. This is the selected four-card art-direction board, not a full application screen. The new navigation, forms and journey layouts are intentional additions required by the brief. The six generated contact sheets extend the selected art direction to 36 cards; the selected source itself supplies the card back.

Implementation: `http://terminal.local:4173/` and the production self-contained build at `/pages/index.html`.

Desktop CSS viewport: 1363 × 936; captured image: 1348 × 926, slight browser capture normalization. No pixel-exact comparison of the full app to the card board is claimed. Mobile iframe CSS viewport: 390 × 844; content width 375 after scrollbar. Mobile screenshot crops are 390 × 844 at 1:1, extracted from the saved browser capture without resizing. Layout DOM checks reported clientWidth = scrollWidth = 375.

Evidence:

- `qa/home-desktop-final.png`: production build, desktop home.
- `qa/reveal-desktop.png`: enlarged card and contextual copy.
- `qa/mobile.png`: mobile home.
- `qa/reveal-mobile.png`: mobile enlarged card; primary next-card control fits the viewport.
- `qa/result-mobile.png`: five-card result arranged as three cards and two cards, with scrolling below.
- `qa/result-export.png`: actual downloaded PNG, 1080 × 1865, complete story, note, date, card images and final suggestion.

The source board and the final desktop/mobile captures were opened together in the same comparison input. Focused enlarged-card captures were checked for cream label bands, image edges, type clarity and proportions. Card-board and application-state differences are intentional rather than alignment errors.

## Findings and fixes

- Resolved P0: HTTP preview lacked `crypto.randomUUID`, so the first start action failed. Replaced it with a random 16-byte identifier from `crypto.getRandomValues`. Re-tested three-card, five-card and the standalone one-card flow successfully.
- Resolved P2: mobile fullscreen icon lost its accessible name when the text label was hidden. Added an explicit dynamic aria-label; subsequent mobile DOM shows “全屏牌桌”.
- Resolved P2: modal keyboard focus could reach obscured controls. Added focus entry, Tab containment, focus restoration and background scroll locking. The final mobile modal capture shows the close and next actions in view.
- Resolved persistence risk found during concurrent development previews: unrelated draft/settings changes could overwrite stored history with stale tab state. Preserve the stored history unless this tab explicitly changes its own history. Saved five-step answers and notes survived reload and reopening.

## Required fidelity surfaces

- Fonts and typography: generated labels preserve serif Chinese title/prompt treatment. App headings use Chinese serif fallbacks; controls use the system sans stack. Desktop hierarchy and mobile wrapping are clean. Small collection thumbnails are intended to open an enlarged readable card.
- Spacing and rhythm: cream margins, large imagery and restrained controls follow the source's airy presentation. Fan overlap on home is deliberate. Mobile results wrap in 3 + 2 columns; no document horizontal overflow was observed.
- Colors and tokens: warm cream paper, muted gold, slate blue and Mediterranean light remain consistent with the source. Active modes, buttons and dimmed modal backgrounds have distinct states.
- Image quality: all card and hero imagery is image-generated art, not CSS/SVG replacement illustrations. WebP conversion preserves source dimensions. Crop coordinates retain card labels and borders; enlarged views and the exported PNG are legible.
- Copy and content: image association, explicitly fictional local stories, and personal notes. No prediction, fortune score or psychological assessment claims. Result questions and action suggestions refer to present-day reflection.

## Functional checks

- Three-card shuffle → distinct selection → enlarged successive reveals → story path selection → personal ending → archive → PNG export.
- Five-card mobile selection and reveal, named questions, note entry, archive, reload, reopen and answer persistence.
- One-card complete flow in the self-contained production HTML.
- Music mode change and pause controls. Web Audio initialized without app errors; subjective audio listening quality was not measured.
- Collection lists all 36 cards and reflects five collected cards.
- Final application console check contained browser-extension metadata noise only, with no new app error in the inspected final flow.
- `npm run build` and standalone Pages packaging succeeded. Main image payload reduced from about 22 MB PNG to about 4.3 MB WebP. Standalone HTML is about 6.1 MB.

## Comparison history

Initial desktop and mobile captures established the art direction. The HTTP start issue and mobile accessible label/focus issues were corrected before final acceptance. Final combined comparison used the source board, `home-desktop-final.png`, `reveal-mobile.png`, and `result-mobile.png`; no actionable P0/P1/P2 visual findings remain.

## Remaining limits

Native fullscreen and file sharing depend on browser support; page-filling layout and image download/long-press are available fallbacks. This was a Chrome desktop browser check plus a 390 px iframe layout check, not a physical iPhone audio/share test. Platform-specific content approval is outside this GitHub preview.

## Implementation checklist

- [x] Preserve selected art direction and original site independence.
- [x] Complete three modes and local journaling.
- [x] Verify desktop, mobile and export output.
- [x] Prepare self-contained Pages build and editable source package.
- [ ] Create a new GitHub repository and verify its Pages URL after authenticated publishing.
