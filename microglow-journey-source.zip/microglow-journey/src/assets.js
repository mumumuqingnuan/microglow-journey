// The self-contained GitHub build embeds the same optimized images.
export const asset = name => window.__MICROGLOW_ASSETS?.[name] || `./assets/${name}.webp`;
