import React from 'react';
import {BookOpen,ArrowRight,FlowerLotus,PencilLine} from '@phosphor-icons/react';
import {JOURNEY_TONES} from './story';

export function StoryPanel({story,onChoose}){
 const complete=story.decision!==null;
 return <article className="story-panel story-adventure">
  <div className="panel-heading"><span className="tiny-icon"><BookOpen size={23}/></span><div><small>{JOURNEY_TONES.find(t=>t.id===story.tone)?.name} · 这一页虚构的小故事</small><h2>{story.title}</h2></div></div>
  <p className="story-teaser">{story.teaser}</p>
  <div className="story-prose">{story.opening.map((p,i)=><p key={i}>{p}</p>)}</div>
  <div className="story-chapter"><span>途中，发生了一件事</span></div>
  <div className="story-prose">{story.encounter.map((p,i)=><p key={i}>{p}</p>)}</div>
  <p className="story-clue">{story.clue}</p>
  <div className="story-fork"><h3>{complete?'你在这里选择了':'这一次，你想怎么做？'}</h3><p>{complete?'另一条岔路也还在，可以回去看看。':'跟着好奇心选一个动作，再翻开结局。'}</p>
   <div className="story-choices story-actions" role="group" aria-label="选择故事行动">{story.choices.map(c=><button key={c.index} className={story.decision===c.index?'chosen':''} aria-pressed={story.decision===c.index} onClick={()=>onChoose(c.index)}>{c.label}<ArrowRight size={16}/></button>)}</div>
  </div>
  {complete&&<section className="story-resolution" aria-live="polite" aria-label="旅途结局" key={story.decision}>
   <div className="story-chapter"><span>旅途的另一面</span></div>
   <div className="story-prose">{story.ending.map((p,i)=><p key={i}>{p}</p>)}</div>
   <div className="story-keepsake"><FlowerLotus size={27} weight="light"/><div><small>这次带回的小礼物</small><h3>{story.keepsake.name}</h3><p>{story.keepsake.description}</p></div></div>
   <div className="story-question"><PencilLine size={20}/><span>哪一刻让你意外、想笑，或想停留？把它留在手记里。</span></div>
  </section>}
 </article>;
}
