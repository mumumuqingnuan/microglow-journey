import { CARDS,MODES,makeStory } from './data';
const cache=new Map();
export function loadImage(src){if(!cache.has(src))cache.set(src,new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>{cache.delete(src);reject(new Error('图片还没加载好，请稍后再试。'));};img.src=src;}));return cache.get(src);}
export async function exportJourney(s){
 const cards=s.selected.map(id=>CARDS[id]);await Promise.all(cards.map(c=>loadImage(c.sheet)));
 await document.fonts.ready;const c=document.createElement('canvas'),x=c.getContext('2d');c.width=1080;c.height=1100;
 const font='"Noto Serif CJK SC", "Songti SC", "STSong", serif';
 function lines(text,width,size){x.font=`${size}px ${font}`;const out=[];for(const para of String(text||'').split('\n')){let line='';for(const ch of para){if(x.measureText(line+ch).width>width&&line){out.push(line);line='';}line+=ch;}out.push(line);}return out;}
 const mode=MODES.find(m=>m.id===s.mode),q=lines(s.question||'给今天留一点微光',920,30);
 const story=s.mode==='story'?makeStory(s.selected,s.choice):s.mode==='spark'?cards[0].scene:'沿着这些画面，慢慢整理此刻的想法。';
 const storyLines=lines(story,920,29),noteLines=lines(s.notes||'',920,29);
 const answers=cards.flatMap((card,i)=>s.answers?.[i]?[...lines(`${mode.positions[i]} · ${card.name}`,920,26),...lines(s.answers[i],920,28),'']:[]);
 const cols=cards.length===1?1:3,rows=Math.ceil(cards.length/cols),cw=cards.length===1?285:270,ch=cards.length===1?565:538;
 const advice=lines(cards[cards.length-1].action,870,29);
 c.height=Math.ceil(300+q.length*43+rows*(ch+46)+95+storyLines.length*46+(noteLines.length?100+noteLines.length*45:0)+(answers.length?50+answers.length*44:0)+advice.length*44+240);
 x.fillStyle='#faf4e9';x.fillRect(0,0,c.width,c.height);x.fillStyle='#b99161';x.font=`22px ${font}`;x.fillText('月 隐   ·   微 光 旅 途',80,72);
 x.fillStyle='#35475a';x.font=`46px ${font}`;x.fillText(mode.name,80,146);
 x.fillStyle='#7c7b76';x.font=`23px ${font}`;x.fillText(new Date(s.startedAt).toLocaleString('zh-CN',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false})+'  ·  '+s.mood,80,194);
 let y=253;
 function print(ls,size,color='#45505a',height=45){x.fillStyle=color;x.font=`${size}px ${font}`;for(const line of ls){x.fillText(line,80,y);y+=height;}}
 print(q,30,'#35475a',43);y+=25;
 for(let i=0;i<cards.length;i++){const card=cards[i],row=Math.floor(i/cols),col=i%cols,rowCount=Math.min(cols,cards.length-row*cols),start=(1080-(rowCount*cw+(rowCount-1)*35))/2,px=start+col*(cw+35),py=y+row*(ch+46);const img=await loadImage(card.sheet);x.save();x.beginPath();x.roundRect(px,py,cw,ch,17);x.clip();x.drawImage(img,...card.crop,px,py,cw,ch);x.restore();}
 y+=rows*(ch+46)+35;print([s.mode==='story'?'这一段小故事':'画面带来的想法'],26,'#a2754c',42);print(storyLines,29,'#45505a',46);
 if(answers.length){y+=32;print(answers,28,'#45505a',44);}
 if(s.notes?.trim()){y+=40;print(['我的手记'],26,'#a2754c',44);print(noteLines,29,'#45505a',45);}
 y+=28;x.fillStyle='#eee5d5';x.fillRect(60,y,960,advice.length*44+112);y+=44;print(['留给自己的一句话'],24,'#a2754c',42);print(advice,29,'#35475a',44);y+=80;
 x.fillStyle='#989184';x.font=`21px ${font}`;x.fillText('图像联想  ·  故事创作  ·  个人手记',80,y);
 const blob=await new Promise((res,rej)=>c.toBlob(b=>b?res(b):rej(new Error('图片保存失败，请重试。')),'image/png'));
 return {url:URL.createObjectURL(blob),blob,name:`微光旅途_${new Date(s.startedAt).toLocaleDateString('sv-SE')}.png`};
}
