import {STORY_ROUTES} from './storyContent.js';

export const JOURNEY_TONES = [
 {id:'any',name:'交给旅途',desc:'不知道会遇见什么，也很好。'},
 {id:'wonder',name:'来一点奇遇',desc:'跟着线索，走到没想过的地方。'},
 {id:'comfort',name:'想被轻轻接住',desc:'不必样样顺利，也有人留一盏灯。'},
 {id:'surprise',name:'给我点惊喜',desc:'允许计划拐弯，遇见一点好笑和惊喜。'},
];

// The second card supplies the clue, and changes which two actions are available.
const CLUES = [
 "先看仔细一点。故事里最不起眼的地方，会不会正藏着入口？",
 "如果多听一会儿，说不定能听见事情的另一面。",
 "来路上有没有错过什么？回头，也算一种出发。",
 "不用追上所有线索。哪一件小事最让你放不下？",
 "眼前看见的，和想象中的，未必是同一回事。值得再瞧一眼。",
 "一个问号也能当钥匙。你会先问谁，或者问什么？",
 "有没有一个办法，虽然有点笨，却让你很想试一次？",
 "不必提前知道结局。先走一步，路可能就会露出来。",
 "整个难题太大，那就先从手边最小的一件事开始。",
 "如果肯在这里多留十分钟，会错过什么，又会遇见什么？",
 "一次不成也没关系，换个节奏，也许还能继续玩下去。",
 "在这段故事里，你不一定非得做独自解决一切的主角。",
 "向陌生人打声招呼，会不会多出一个意料之外的同伴？",
 "把那句没好意思说的话说出来，事情会变成什么样？",
 "对方会怎么回答，你还不知道。这正是值得继续的地方。",
 "不一定需要漂亮的办法，陪一个人待一会儿，也能成为一段情节。",
 "有的事适合独自试，有的事可以请人搭把手。这回你想怎么做？",
 "如果故事里有一句谢谢，你最想把它留在哪一个瞬间？",
 "退开半步看一看，也许比立刻凑上前，更容易看见全貌。",
 "两条路不必都走。现在最舍不得错过的是哪一条？",
 "不想接受原来的安排，也可以。故事还有别的写法。",
 "有些东西你想留在自己手里。能不能找个不必交出它们的办法？",
 "先别把门关死，留一道缝，看看还有什么会经过。",
 "这段故事没有替你规定标准答案。你可以选自己好奇的那边。",
 "原计划拐个弯，会是麻烦，还是一张新邀请？",
 "事情停在旧办法和新办法之间。这个空当，刚好够试一种可能。",
 "如果暂时放下最初的计划，还剩下什么值得你留下？",
 "不必推倒重来。只挪动一个小地方，结局会不会变样？",
 "如果认真地胡闹一下，会不会冒出一个没人想过的玩法？",
 "小小的可能还没长大。你愿意替哪一个多等一会儿？",
 "累了就不必把这段奇遇做成任务。歇一下，也可以写进故事。",
 "也许不必立刻赶路，留在这里听一听，会不会有另一种收获？",
 "别急着填满空白。安静的那一格，可能正等着一个新主意。",
 "慢半拍也不一定错过。有些相遇，只有走慢一点才赶得上。",
 "画面里的温热提醒你：一件很小、很具体的好事，也能让情节转弯。",
 "这场意外会停在哪里？你想给它找一个怎样的落脚处？"
];

// A card-specific epilogue is part of the result and is kept in saved stories/exports.
const GIFTS = [
 ['一张镂空的小窗卡','把它举向光，原本普通的地方也能装进一小片风景。'],
 ['一枚能装进掌心的贝壳','你把它贴近耳边，听见的不是答案，而是这一趟热闹的回声。'],
 ['一张背面画着来路的明信片','原来回头看，也能发现已经走了这么远。'],
 ['一朵压平的小花','夹进书里以后，忙碌的页码间就多了一个可以停留的地方。'],
 ['一颗有两种颜色的海玻璃','转一下，它就换一种光。你没有急着给它定下唯一的名字。'],
 ['一只透明的小玻璃瓶','里面什么也没装。你决定让它等下一次真正想珍藏的东西。'],
 ['一枚写着“试过了”的小印章','盖得歪一点也算数；这趟旅途没有要求整齐。'],
 ['一张没有印终点的车票','空白那一格先留着，回来以后也还能有新的出发。'],
 ['三颗大小不一的圆石','你把它们排成一条很短的小路，看上去已经足够走第一步。'],
 ['一本只有七页的小册子','它装不下宏大的计划，刚好装得下一件你在意的事。'],
 ['一枚橄榄叶书签','不必一天就长成一棵树，今天先记住这一点绿。'],
 ['一张多画了一把椅子的卡片','下次需要帮忙时，也许可以从一句“你有空吗”开始。'],
 ['两枚可以拼在一起的小纽扣','它们不一定永远挨着，重逢时依然能认出彼此。'],
 ['一只没有封口的小信封','话可以慢慢写，寄不寄，由你自己决定。'],
 ['一面掌心大的小镜子','它照不见别人怎么想，却能照见你笑了一下。'],
 ['一只印着两杯茶的杯垫','不说话的那一会儿，也算一起度过的好时光。'],
 ['一块不规则的蓝色瓷片','单看它很奇怪，放进一幅画里却刚刚合适。'],
 ['一束用纸折的小野花','没有署名；想到谁时，就可以把谢意给谁。'],
 ['一段系成活结的彩绳','松一点或紧一点，都可以重新调整。'],
 ['一张只留一个空格的清单','今天不必把所有格子填满，挑一件喜欢的就好。'],
 ['一枚可以翻面的门牌','一面写着欢迎，一面写着歇一会儿；两面都被认真画好了。'],
 ['一颗装在纸袋里的柑橘种子','它暂时还只是一颗种子，但已经值得留一个位置。'],
 ['一把没有配门的小钥匙','你不用立刻决定打开什么，先允许自己保留一点可能。'],
 ['一只掌心大的纸船','船头朝哪里，这次没有别人替你摆好。'],
 ['一张故意多画一个转角的地图','那一小段绕路，成了你最想讲给别人听的部分。'],
 ['一枚画着半座桥的徽章','另一半还没画好，故事也可以先走到这里。'],
 ['一圈松松绕好的线','它没有绑住什么，反而把口袋里最柔软的位置留了出来。'],
 ['一支短短的彩色铅笔','原来的路线不必擦掉，旁边再画一条也可以。'],
 ['一张亮蓝色的小贴纸','贴在旧物上，它就有了只有你知道的新故事。'],
 ['一片带着新绿的叶子拓印','看起来变化很小，过一阵再回头，也许会认不出来。'],
 ['一张印着灯塔的休息券','没有截止日期，也不用先证明自己足够辛苦。'],
 ['一颗画着小港湾的石子','握在手里时，你记起路上确实有过一个让人安心的地方。'],
 ['一张干净的米白色纸','你没有急着写满它。把余地带回家，也是一份收获。'],
 ['一枚指针慢半拍的纸表','它不负责报时，只负责提醒你偶尔看看路边。'],
 ['一份手写的简易早餐单','材料都很普通，但你忽然有点期待明天早上。'],
 ['一张画着暖灯的小贴画','回去的路上，你把它放在最容易找到的口袋里。'],
];

function hash(text){let h=2166136261;for(const c of String(text)){h=Math.imul(h^c.charCodeAt(0),16777619);}return h>>>0;}
export function createStoryState(session,recentRouteIds=[]){
 const tone=JOURNEY_TONES.some(t=>t.id===session.journeyTone)?session.journeyTone:'any';
 let pool=STORY_ROUTES.filter(r=>tone==='any'||r.tone===tone);
 // Avoid the most recent route where possible, without exhausting a chosen tone.
 const fresh=pool.filter(r=>!recentRouteIds.slice(0,2).includes(r.id));
 if(fresh.length)pool=fresh;
 else {const other=pool.filter(r=>r.id!==recentRouteIds[0]);if(other.length)pool=other;}
 const route=pool[hash(`${session.id}:${session.selected[0]}`)%pool.length];
 return {version:2,routeId:route.id,decision:null};
}
export function resolveStory(session,cards){
 if(session?.mode!=='story'||session.story?.version!==2)return null;
 if(session.story.snapshot)return session.story.snapshot;
 const route=STORY_ROUTES.find(r=>r.id===session.story.routeId);
 if(!route||session.selected.length!==3)return null;
 const [first,second,third]=session.selected.map(id=>cards[id]);
 if(!first||!second||!third)return null;
 const omitted=second.id%3;
 const choices=route.choices.map((c,index)=>({...c,index})).filter(c=>c.index!==omitted);
 const decision=choices.find(c=>c.index===session.story.decision);
 const gift=GIFTS[third.id];
 return {
  version:2,routeId:route.id,tone:route.tone,title:route.title,teaser:route.teaser,
  opening:[first.scene,route.opening],encounter:[route.encounter],clue:`「${second.name}」带来一个念头：${CLUES[second.id]}`,
  choices:choices.map(c=>({index:c.index,label:c.label})),decision:decision?.index??null,
  choiceLabel:decision?.label||'',
  ending:decision?[decision.consequence,decision.reveal,decision.afterglow]:[],
  keepsake:decision?{name:decision.keepsake,description:`你把${gift[0]}也收进旅途的小纸袋。${gift[1]}`} : null,
  cardGift:gift[0],
 };
}
export function chooseStory(session,cards,index){
 const next={...session,story:{...session.story,decision:index,snapshot:undefined}};
 const result=resolveStory(next,cards);
 if(!result||result.decision===null)return session.story;
 return {...next.story,snapshot:result};
}
export function storyText(story){
 if(!story)return '';
 return [story.title,...story.opening,...story.encounter,story.clue,...(story.decision===null?[]:[`你的选择：${story.choiceLabel}`,...story.ending,`旅途纪念物 · ${story.keepsake.name}`,story.keepsake.description])].join('\n\n');
}
