export class Soundscape {
 constructor(){this.ctx=null;this.on=false;this.volume=.28;this.kind='tide';this.tick=0;this.timer=null;this.noise=null;}
 async start(){
  if(!this.ctx){
   this.ctx=new (window.AudioContext||window.webkitAudioContext)();const c=this.ctx;
   this.master=c.createGain();this.master.gain.value=0;this.master.connect(c.destination);
   this.delay=c.createDelay(2);this.delay.delayTime.value=.48;
   const feedback=c.createGain();feedback.gain.value=.22;this.delay.connect(feedback);feedback.connect(this.delay);
   const wet=c.createGain();wet.gain.value=.28;this.delay.connect(wet);wet.connect(this.master);
   const buffer=c.createBuffer(1,c.sampleRate*4,c.sampleRate),data=buffer.getChannelData(0);let last=0;
   for(let i=0;i<data.length;i++){last=(last+(.02*(Math.random()*2-1)))/1.02;data[i]=last*3.5;}
   this.noise=c.createBufferSource();this.noise.buffer=buffer;this.noise.loop=true;
   const filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=500;
   this.wave=c.createGain();this.wave.gain.value=.035;
   this.noise.connect(filter);filter.connect(this.wave);this.wave.connect(this.master);this.noise.start();
  }
  await this.ctx.resume();this.on=true;this.master.gain.setTargetAtTime(this.volume,this.ctx.currentTime,.5);
  if(!this.timer){this.step();this.timer=setInterval(()=>this.step(),800);}
 }
 pause(){if(!this.ctx)return;this.on=false;clearInterval(this.timer);this.timer=null;this.master.gain.setTargetAtTime(0,this.ctx.currentTime,.3);}
 setVolume(v){this.volume=v;if(this.on)this.master.gain.setTargetAtTime(v,this.ctx.currentTime,.15);}
 setKind(k){this.kind=k;this.tick=0;}
 tone(f,duration=3,amplitude=.11){if(!this.ctx||!this.on)return;const c=this.ctx,t=c.currentTime,osc=c.createOscillator(),g=c.createGain();osc.type=this.kind==='paper'?'triangle':'sine';osc.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(amplitude,t+.08);g.gain.exponentialRampToValueAtTime(.0001,t+duration);osc.connect(g);g.connect(this.master);g.connect(this.delay);osc.start(t);osc.stop(t+duration+.1);}
 step(){if(!this.on)return;const scales={tide:[220,293.66,329.63,440,493.88,587.33],paper:[196,261.63,293.66,392,440,523.25],glow:[261.63,329.63,392,523.25,587.33,659.25]},s=scales[this.kind];if(this.tick%2===0)this.tone(s[(this.tick/2+Math.floor(this.tick/16))%s.length],3.4,this.kind==='glow'?.075:.055);if(this.tick%12===0){this.tone(s[0]/2,9,.055);this.tone(s[2]/2,9,.028);}if(this.wave)this.wave.gain.setTargetAtTime(this.kind==='tide'?.03+.015*Math.sin(this.tick/6):.012,this.ctx.currentTime,1);this.tick++;}
 chime(){this.tone(659.25,1.5,.10);setTimeout(()=>this.tone(880,1.6,.045),100);}
 destroy(){this.pause();this.ctx?.close();}
}

