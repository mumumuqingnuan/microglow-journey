# Prototype Instructions

## Approved product direction

Build a separate application, 月隐 · 微光旅途, with a new GitHub repository and Pages address. Never modify or deploy over moonveil-tarot. The exact selected visual reference is ../upload/image-edit-target-58f351d157076d72.png: warm Mediterranean scenes, cream paper card labels, muted gold accents, and a dark blue card back. Keep generated artwork, shuffle/large flip/glow particles/fullscreen/music, and exportable results. Position the product as image association, fictional story creation, and personal journaling; do not present random cards as fortune telling or a psychological assessment. Keep 1-card inspiration, 3-card story, and 5-card journal modes. Personal entries stay in this browser.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## Story experience (2026-09-25)

Three-card journeys should produce interesting fictional events, meaningful choices, unexpected turns, comfort and surprise. Avoid merely concatenating card scenery or ending every journey with generic reassurance. Preserve the existing card artwork and interactions. Keep previously saved stories unchanged; new stories, history and image exports must share the exact same persisted result.
